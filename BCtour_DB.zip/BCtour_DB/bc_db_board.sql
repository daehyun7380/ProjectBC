-- MySQL dump 10.13  Distrib 8.0.21, for Win64 (x86_64)
--
-- Host: localhost    Database: bc_db
-- ------------------------------------------------------
-- Server version	8.0.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `board`
--

DROP TABLE IF EXISTS `board`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `board` (
  `bno` int NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `content` text NOT NULL,
  `writer` varchar(20) NOT NULL,
  `view_cnt` int DEFAULT '0',
  `reg_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `up_date` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`bno`)
) ENGINE=InnoDB AUTO_INCREMENT=184 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `board`
--

LOCK TABLES `board` WRITE;
/*!40000 ALTER TABLE `board` DISABLE KEYS */;
INSERT INTO `board` VALUES (161,'title1','content1','admin',1,'2022-11-03 11:33:32','2022-11-03 11:33:32'),(162,'title2','content2','admin',0,'2022-11-03 11:33:32','2022-11-03 11:33:32'),(163,'title3','content3','admin',0,'2022-11-03 11:33:32','2022-11-03 11:33:32'),(164,'title4','content4','admin',0,'2022-11-03 11:33:32','2022-11-03 11:33:32'),(165,'title5','content5','admin',0,'2022-11-03 11:33:32','2022-11-03 11:33:32'),(166,'title6','content6','admin',0,'2022-11-03 11:33:32','2022-11-03 11:33:32'),(167,'title7','content7','admin',0,'2022-11-03 11:33:32','2022-11-03 11:33:32'),(168,'title8','content8','admin',0,'2022-11-03 11:33:32','2022-11-03 11:33:32'),(169,'title9','content9','admin',0,'2022-11-03 11:33:32','2022-11-03 11:33:32'),(170,'title10','content10','admin',0,'2022-11-03 11:33:32','2022-11-03 11:33:32'),(171,'title11','content11','admin',2,'2022-11-03 11:33:32','2022-11-03 11:33:32'),(172,'title12','content12','admin',0,'2022-11-03 11:33:32','2022-11-03 11:33:32'),(173,'title13','content13','admin',0,'2022-11-03 11:33:32','2022-11-03 11:33:32'),(174,'title14','content14','admin',0,'2022-11-03 11:33:32','2022-11-03 11:33:32'),(175,'title15','content15','admin',1,'2022-11-03 11:33:32','2022-11-03 11:33:32'),(176,'title16','content16','admin',0,'2022-11-03 11:33:32','2022-11-03 11:33:32'),(177,'title17','content17','admin',1,'2022-11-03 11:33:32','2022-11-03 11:33:32'),(178,'title18','content18','admin',0,'2022-11-03 11:33:32','2022-11-03 11:33:32'),(179,'title19','content19','admin',7,'2022-11-03 11:33:32','2022-11-03 11:33:32'),(181,'안녕하세요','<p>안녕하세요 반갑습니다</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><img alt=\"\" src=\"/ch1/resources/img/bb7ccbe0-bdb1-4860-a185-238881058c19logo.png\" style=\"height:55px; width:222px\" />입니다</p>\r\n','admin',14,'2022-11-07 09:33:29','2022-11-11 12:05:51'),(182,'안녕하세요2','<p>ㅁㄴㅇㅁㅇㄴㅁ</p>\r\n\r\n<p><img alt=\"\" src=\"/ch1/resources/img/a81fa420-5c57-47ce-8d78-8f12b7d8eafdlogo.jpg\" style=\"height:55px; width:222px\" /></p>\r\n\r\n<p>ㅁㄴㅇㄴㅁㅇㅁㄴ</p>\r\n','admin',11,'2022-11-11 17:24:38','2022-11-11 17:24:38'),(183,'asdasd123','<p>asdasd123</p>\r\n','admin',3,'2022-11-23 16:41:49','2022-11-23 16:41:59');
/*!40000 ALTER TABLE `board` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-01-13 20:16:41
