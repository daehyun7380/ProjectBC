-- MySQL dump 10.13  Distrib 8.0.21, for Win64 (x86_64)
--
-- Host: localhost    Database: bc_db
-- ------------------------------------------------------
-- Server version	8.0.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `community`
--

DROP TABLE IF EXISTS `community`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `community` (
  `comm_num` int NOT NULL AUTO_INCREMENT,
  `comm_title` varchar(45) NOT NULL,
  `comm_content` text NOT NULL,
  `comm_writer` varchar(45) NOT NULL,
  `comm_view` int DEFAULT '0',
  `comm_comment` int DEFAULT '0',
  `comm_reg_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `comm_up_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`comm_num`)
) ENGINE=InnoDB AUTO_INCREMENT=309 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community`
--

LOCK TABLES `community` WRITE;
/*!40000 ALTER TABLE `community` DISABLE KEYS */;
INSERT INTO `community` VALUES (258,'1번글','no content','asdf',0,0,'2022-11-17 07:39:13',NULL),(259,'2번글','no content','asdf',0,0,'2022-11-17 07:39:13',NULL),(260,'3번글','no content','asdf',0,0,'2022-11-17 07:39:13',NULL),(261,'4번글','no content','asdf',0,0,'2022-11-17 07:39:13',NULL),(262,'5번글','no content','asdf',0,0,'2022-11-17 07:39:13',NULL),(263,'6번글','no content','asdf',0,0,'2022-11-17 07:39:13',NULL),(264,'7번글','no content','asdf',0,0,'2022-11-17 07:39:13',NULL),(265,'8번글','no content','asdf',0,0,'2022-11-17 07:39:13',NULL),(266,'9번글','no content','asdf',0,0,'2022-11-17 07:39:13',NULL),(267,'10번글','no content','asdf',0,0,'2022-11-17 07:39:13',NULL),(268,'11번글','no content','asdf',0,0,'2022-11-17 07:39:13',NULL),(269,'12번글','no content','asdf',0,0,'2022-11-17 07:39:13',NULL),(270,'13번글','no content','asdf',0,0,'2022-11-17 07:39:13',NULL),(271,'14번글','no content','asdf',0,0,'2022-11-17 07:39:13',NULL),(272,'15번글','no content','asdf',0,0,'2022-11-17 07:39:13',NULL),(273,'16번글','no content','asdf',0,0,'2022-11-17 07:39:13',NULL),(274,'17번글','no content','asdf',0,0,'2022-11-17 07:39:13',NULL),(275,'18번글','no content','asdf',0,0,'2022-11-17 07:39:13',NULL),(276,'19번글','no content','asdf',0,0,'2022-11-17 07:39:13',NULL),(277,'20번글','no content','asdf',0,0,'2022-11-17 07:39:13',NULL),(278,'21번글','no content','asdf',0,0,'2022-11-17 07:39:13',NULL),(279,'22번글','no content','asdf',0,0,'2022-11-17 07:39:13',NULL),(280,'23번글','no content','asdf',0,0,'2022-11-17 07:39:13',NULL),(281,'24번글','no content','asdf',0,0,'2022-11-17 07:39:13',NULL),(282,'25번글','no content','asdf',0,0,'2022-11-17 07:39:13',NULL),(283,'26번글','no content','asdf',0,0,'2022-11-17 07:39:13',NULL),(284,'27번글','no content','asdf',0,0,'2022-11-17 07:39:13',NULL),(285,'28번글','no content','asdf',0,0,'2022-11-17 07:39:13',NULL),(286,'29번글','no content','asdf',0,0,'2022-11-17 07:39:13',NULL),(287,'30번글','no content','asdf',0,0,'2022-11-17 07:39:13',NULL),(288,'31번글','no content','asdf',0,0,'2022-11-17 07:39:13',NULL),(289,'32번글','no content','asdf',0,0,'2022-11-17 07:39:13',NULL),(290,'33번글','no content','asdf',0,0,'2022-11-17 07:39:13',NULL),(291,'34번글','no content','asdf',0,0,'2022-11-17 07:39:13',NULL),(292,'35번글','no content','asdf',0,0,'2022-11-17 07:39:13',NULL),(293,'36번글','no content','asdf',0,0,'2022-11-17 07:39:13',NULL),(294,'37번글','no content','asdf',0,0,'2022-11-17 07:39:13',NULL),(295,'38번글','no content','asdf',0,0,'2022-11-17 07:39:13',NULL),(296,'39번글','no content','asdf',0,0,'2022-11-17 07:39:13',NULL),(297,'40번글','no content','asdf',0,0,'2022-11-17 07:39:13',NULL),(298,'41번글','no content','asdf',0,0,'2022-11-17 07:39:13',NULL),(299,'42번글','no content','asdf',0,0,'2022-11-17 07:39:13',NULL),(300,'43번글','no content','asdf',0,0,'2022-11-17 07:39:13',NULL),(301,'44번글','no content','asdf',1,0,'2022-11-17 07:39:14',NULL),(302,'45번글','no content','asdf',0,0,'2022-11-17 07:39:14',NULL),(303,'46번글','no content','asdf',0,0,'2022-11-17 07:39:14',NULL),(304,'47번글','no content','asdf',0,0,'2022-11-17 07:39:14',NULL),(305,'48번글','no content','asdf',1,0,'2022-11-17 07:39:14',NULL),(306,'49번글','<ol>\r\n	<li>리스트1</li>\r\n	<li>리스트2</li>\r\n</ol>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<ul>\r\n	<li>리스트a</li>\r\n	<li>리스트b</li>\r\n</ul>\r\n','asdf',30,12,'2022-11-17 07:39:14','2022-11-18 01:15:44'),(307,'50번글','<ol>\r\n	<li>no content</li>\r\n	<li>2번리스트</li>\r\n	<li>3번리스트</li>\r\n	<li><strong>4번 굵은글씨</strong></li>\r\n	<li><strong><em>5번 굵은 기울임</em></strong>\r\n	<ol>\r\n		<li><s>6번 취소선 들여쓰기</s></li>\r\n	</ol>\r\n	</li>\r\n</ol>\r\n\r\n<ul>\r\n	<li>7번 점 리스트</li>\r\n</ul>\r\n\r\n<p>8번 내어쓰기</p>\r\n\r\n<blockquote>\r\n<p>9번 인용단락</p>\r\n</blockquote>\r\n\r\n<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"width:500px\">\r\n	<tbody>\r\n		<tr>\r\n			<td>1</td>\r\n			<td>0</td>\r\n			<td>번</td>\r\n		</tr>\r\n		<tr>\r\n			<td>표</td>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<hr />\r\n<p>줄 삽입</p>\r\n\r\n<p>&oelig;특수문자</p>\r\n','asdf',9,2,'2022-11-17 07:39:14','2022-11-18 01:14:45'),(308,'커피원두','<p>&nbsp;<img alt=\"\" src=\"/ch1/resources/img/bca4ea8a-bf29-4369-ab18-e071bcc53cdb커피원두.jpg\" style=\"height:140px; width:200px\" />&nbsp; 커피원두이다</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><img alt=\"\" src=\"/ch1/resources/img/a9ce14a7-864a-4609-a86d-f8ffd8efa542cupcakes.jpg\" style=\"height:133px; width:200px\" />&nbsp;컵케익이다</p>\r\n','asd',5,0,'2022-11-23 07:50:12','2022-11-23 07:50:45');
/*!40000 ALTER TABLE `community` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-01-13 20:16:41
