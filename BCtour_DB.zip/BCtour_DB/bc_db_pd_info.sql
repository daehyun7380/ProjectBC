-- MySQL dump 10.13  Distrib 8.0.21, for Win64 (x86_64)
--
-- Host: localhost    Database: bc_db
-- ------------------------------------------------------
-- Server version	8.0.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `pd_info`
--

DROP TABLE IF EXISTS `pd_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pd_info` (
  `pd_num` int NOT NULL AUTO_INCREMENT,
  `pd_city` varchar(45) DEFAULT NULL,
  `pd_img` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `pd_title` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `pd_subtitle` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `pd_days` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `pd_price` int DEFAULT NULL,
  `pd_transport` char(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `pd_departDay` timestamp NULL DEFAULT NULL,
  `pd_departStart` varchar(40) DEFAULT NULL,
  `pd_departEnd` varchar(40) DEFAULT NULL,
  `pd_deportDay` timestamp NULL DEFAULT NULL,
  `pd_deportStart` varchar(40) DEFAULT NULL,
  `pd_deportEnd` varchar(40) DEFAULT NULL,
  `pd_visitCity` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `pd_totalScore` int DEFAULT '0',
  `pd_totalScoreMember` int DEFAULT '0',
  `pd_buyCnt` int DEFAULT '0',
  `reg_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `reviewCheck` int DEFAULT '0',
  PRIMARY KEY (`pd_num`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pd_info`
--

LOCK TABLES `pd_info` WRITE;
/*!40000 ALTER TABLE `pd_info` DISABLE KEYS */;
INSERT INTO `pd_info` VALUES (13,'UiJeoungBu','angry.PNG','#남산','#남산','2',13000,'버스','2022-12-06 15:00:00','13:00','14:40','2022-12-07 15:00:00','15:30','17:00','서울',0,0,0,'2022-11-24 01:08:21',0),(14,'seoul','5c8efdb557189.jpg','서울 1박 2일#호텔급 #육로버스투어','롯데타워의 모든것을 순회하기 위한 럭셔리 투어!','2',15000,'버스','2022-12-05 15:00:00','11:00','12:30','2022-12-06 15:00:00','16:00','17:30','서울->롯데타워',5,1,2,'2022-11-28 03:19:59',0),(15,'의정부',NULL,'#서울2','#서울2','3',22000,'버스','2022-12-05 15:00:00','11:00','12:30','2022-12-06 15:00:00','16:00','17:30','서울',0,0,0,'2022-11-28 03:20:49',0),(30,'uijeongbu','1272dc18-817c-436d-b9ac-47e0a139e998.jpg','의정부 2일#내차로자유여행#서울출발','의정부에서의 1박 2일!','2',20000,'버스','2022-12-06 15:00:00','12:00','13:00','2022-12-07 15:00:00','12:00','13:00','서울->의정부',2,4,3,'2022-11-28 05:17:08',0),(31,'seoul','GettyImages-471837692.jpg','한강 2일 #인천집결 #한강#롯데타워 ','한강이랑 롯데타워를 즐기기 위한 완벽한 2일!','2',20000,'버스','2022-12-06 15:00:00','12:00','14:00','2022-12-07 15:00:00','12:00','13:00','인천->한강->롯데타워',3,6,4,'2022-11-28 05:21:59',0),(38,'seoul','angry2.png','[연합상품][부산출발] 서울 당일투어 #청와대 #28인승 전용리무진 #경복궁','74년간 베일에 가려져 있던, 국민에게 개방된 청와대 관람. 대한민국 역사문화의 중심지 경복궁 나들이','6',41544,'버스','2022-12-04 15:00:00','09:00','12:00','2022-12-06 15:00:00','12:00','14:00','서울역->청와대',2,4,1,'2022-12-05 02:11:59',0),(39,'seoul','anime screencap, guilty gear, guilty gear xrd,1girl,bishoujo, sunlight,highres, high_quality, high_resolution, masterpiece, super detail,intricate_details,spotlight, blurry backgro s-4281523955.png','테스트','테스트144','3',41544,'버스','2022-12-04 15:00:00','10:00','12:00','2022-12-06 15:00:00','12:00','14:00','서울->롯데타워',0,0,0,'2022-12-05 06:13:51',0),(41,'uijeongbu','9269b1ac-ed62-49c1-bb91-5e6bcc41c105.png','[연합상품][부산출발] 서울 당일투어 #청와대 #28인승 전용리무진 #경복궁','74년간 베일에 가려져 있던, 국민에게 개방된 청와대 관람. 대한민국 역사문화의 중심지 경복궁 나들이','6',41544,'버스','2022-12-04 15:00:00',' 12:00','14:00','2022-12-06 15:00:00','12:00','14:00','서울역->청와대',0,0,0,'2022-12-06 05:30:00',0);
/*!40000 ALTER TABLE `pd_info` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-01-13 20:16:41
